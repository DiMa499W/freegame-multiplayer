const defaultConfig = {
  maxSpeed: 0.5,
  teleportThreshold: 5,
  maxUpdatesPerSec: 20,
  warningThreshold: 3,
  banOnWarning: false,
  slidingWindowMS: 1000,
  debug: false
};

module.exports = function createAntiCheat(config = {}, banCb = null) {
  config = Object.assign({}, defaultConfig, config);
  const state = new Map();

  function log(...args){ if(config.debug) console.log('[AC]', ...args); }

  function onJoin(id, username, initial = { x: 0, y: 0 }) {
    state.set(id, { id, username: username || 'Player', lastX: initial.x || 0, lastY: initial.y || 0, lastTime: Date.now(), warnings: 0, recentTimestamps: [] });
    log('join', id, username);
  }

  function onDisconnect(id) { state.delete(id); log('disconnect', id); }

  function issueWarning(id, reason) {
    const p = state.get(id);
    if(!p) return;
    p.warnings = (p.warnings || 0) + 1;
    log('warning', id, reason, 'count=', p.warnings);
    if(p.warnings >= config.warningThreshold) {
      if(config.banOnWarning) return doBan(id, `auto-ban after ${p.warnings} warnings`);
      if(banCb) banCb(id, p.username, `warnings=${p.warnings}`);
    }
  }

  function doBan(id, reason) {
    const p = state.get(id);
    log('ban', id, reason);
    if(banCb) banCb(id, p?.username || 'unknown', reason);
    state.delete(id);
  }

  function onMove(id, x, y, now = Date.now()) {
    const p = state.get(id);
    if(!p){
      state.set(id, { id, username: 'Player', lastX: x, lastY: y, lastTime: now, warnings: 0, recentTimestamps: [now] });
      return;
    }

    p.recentTimestamps = p.recentTimestamps.filter(t => t > now - config.slidingWindowMS);
    p.recentTimestamps.push(now);
    if(p.recentTimestamps.length > config.maxUpdatesPerSec) issueWarning(id, `flood: ${p.recentTimestamps.length}/${config.maxUpdatesPerSec}`);

    const dt = Math.max((now - (p.lastTime || now)) / 1000, 0.001);
    const dx = x - (p.lastX || x);
    const dy = y - (p.lastY || y);
    const dist = Math.sqrt(dx*dx + dy*dy);

    if(dist > config.teleportThreshold) { doBan(id, `teleport detected dist=${dist.toFixed(2)}`); return; }

    const speed = dist / dt;
    if(speed > config.maxSpeed) issueWarning(id, `speed ${speed.toFixed(2)} > max ${config.maxSpeed}`);
    if(speed > config.maxSpeed * 3) { doBan(id, `excessive speed ${speed.toFixed(2)}`); return; }

    p.lastX = x;
    p.lastY = y;
    p.lastTime = now;
  }

  function periodicCheck() {
    const now = Date.now();
    for(const [id,p] of state.entries()) p.recentTimestamps = p.recentTimestamps.filter(t => t > now - config.slidingWindowMS);
  }

  return { onJoin, onDisconnect, onMove, doBan, issueWarning, periodicCheck, _state: state, _config: config };
};

// frontend/dima.js
(function(){

  /*** COOKIE / POLICY LOGIC ***/
  const panel = document.getElementById('policy-panel');
  const allowBtn = document.getElementById('policy-allow');
  const closeBtn = document.getElementById('policy-close');

  function setCookie(name,value,days){
    const d=new Date();
    d.setTime(d.getTime()+(days*24*60*60*1000));
    document.cookie=`${name}=${value};expires=${d.toUTCString()};path=/`;
  }
  function getCookie(name){
    const v=document.cookie.match('(^|;) ?'+name+'=([^;]*)(;|$)');
    return v?v[2]:null;
  }
  function hidePanel(save=false){
    panel.classList.add('policy-hidden');
    setTimeout(()=> panel?.parentNode?.removeChild(panel),300);
    if(save) setCookie('hax_policy_allowed','1',365);
  }
  if(getCookie('hax_policy_allowed')==='1') panel?.parentNode?.removeChild(panel);
  else{
    allowBtn?.addEventListener('click',()=>hidePanel(true));
    closeBtn?.addEventListener('click',()=>hidePanel(false));
  }

  /*** LOBBY ELEMENTS ***/
  const wrapper=document.querySelector('.wrapper');
  const usernameInput=document.getElementById('username');

  /*** CANVAS SETUP ***/
  const canvas=document.createElement('canvas');
  canvas.style.display='none';
  document.body.appendChild(canvas);
  const ctx=canvas.getContext('2d');
  canvas.width=window.innerWidth;
  canvas.height=window.innerHeight;
  canvas.style.position='fixed';
  canvas.style.top=0;
  canvas.style.left=0;
  canvas.style.zIndex=-1;
  canvas.style.backgroundColor='#fff'; // white background
  window.addEventListener('resize',()=>{ canvas.width=window.innerWidth; canvas.height=window.innerHeight; });

  /*** GAME STATE ***/
  const gameState={
    map: [],
    config: {},
    input:{up:false,down:false,left:false,right:false},
    player:{ x:0, y:0, id:null, username:null, speed:0 },
    players:{}, // all visible players
  };

  /*** LOAD CONFIG ***/
  async function loadConfig(){
    try{
      const res=await fetch('/compiled/json/config.json');
      if(!res.ok) throw new Error('Failed to load config.json');
      const cfg = await res.json();
      gameState.config = cfg;
      gameState.player.speed = cfg.playerSpeed || 0.15;
      gameState.tileSize = cfg.tileSize || 32;
      canvas.style.backgroundColor = cfg.canvasBgColor || "#fff";
    }catch(e){console.error('Error loading config:', e);}
  }

  /*** MAP LOADER ***/
  async function loadMap(){
    try{
      const res=await fetch('/compiled/json/map.json');
      if(!res.ok) throw new Error('Failed to load map.json');
      gameState.map = await res.json();
      console.log('Map loaded');
    }catch(e){console.error('Error loading map:',e);}
  }

  gameState.isWalkable=(x,y)=>{
    const xi=Math.floor(x), yi=Math.floor(y);
    return gameState.map[yi] && gameState.map[yi][xi]===1;
  };

  /*** INPUT HANDLING ***/
  window.addEventListener('keydown',e=>{
    if(e.key==='w') gameState.input.up=true;
    if(e.key==='s') gameState.input.down=true;
    if(e.key==='a') gameState.input.left=true;
    if(e.key==='d') gameState.input.right=true;
  });
  window.addEventListener('keyup',e=>{
    if(e.key==='w') gameState.input.up=false;
    if(e.key==='s') gameState.input.down=false;
    if(e.key==='a') gameState.input.left=false;
    if(e.key==='d') gameState.input.right=false;
  });

  /*** WEBSOCKET / MULTIPLAYER ***/
  let ws;
  async function initWS(){
    if(ws && ws.readyState===WebSocket.OPEN) return;
    await loadConfig();
    const username=usernameInput?.value||'Player';
    const id='player-'+Date.now();
    gameState.player.username=username;
    gameState.player.id=id;

    wrapper.style.display='none';
    canvas.style.display='block';

    await loadMap(); 
    const walkables=[];
    gameState.map.forEach((row,y)=>row.forEach((cell,x)=>{ if(cell===1) walkables.push({x,y}); }));
    const spawn=walkables[Math.floor(Math.random()*walkables.length)];
    gameState.player.x=spawn.x+0.5;
    gameState.player.y=spawn.y+0.5;

    // connect WS
    ws=new WebSocket('ws://localhost');
    ws.onopen=()=> ws.send(JSON.stringify({ type:'join', username, id }));
    ws.onmessage=msg=>{
      try{
        const data=JSON.parse(msg.data);
        if(data.type==='players') gameState.players = data.players;
        if(data.type==='activePlayers'){
          const el=document.getElementById('count');
          if(el) el.textContent=data.count;
        }
      }catch(e){console.warn(e);}
    };
    ws.onclose=()=>console.log('Disconnected');
    ws.onerror=e=>console.error('WebSocket error',e);
  }
  document.getElementById('play')?.addEventListener('click',initWS);
 
  function loop(){
    const { player, players, map, tileSize, input, config } = gameState;
    if(map.length && canvas.style.display!=='none'){
 
      let nx=player.x, ny=player.y;
      if(input.up && gameState.isWalkable(player.x, player.y-0.1)) ny-=player.speed;
      if(input.down && gameState.isWalkable(player.x, player.y+0.1)) ny+=player.speed;
      if(input.left && gameState.isWalkable(player.x-0.1, player.y)) nx-=player.speed;
      if(input.right && gameState.isWalkable(player.x+0.1, player.y)) nx+=player.speed;
      player.x=nx; player.y=ny;
 
      if(ws && ws.readyState===WebSocket.OPEN){
        ws.send(JSON.stringify({ type:'move', x:player.x, y:player.y, id:player.id }));
      }
 
      players[player.id] = { ...player };
 
      const camX = player.x*tileSize - canvas.width/2;
      const camY = player.y*tileSize - canvas.height/2;

      ctx.clearRect(0,0,canvas.width,canvas.height);
 
      map.forEach((row,y)=>row.forEach((cell,x)=>{
        const sx = x*tileSize - camX;
        const sy = y*tileSize - camY;
        if(cell===1){
          const grd = ctx.createLinearGradient(sx,sy,sx+tileSize,sy+tileSize);
          grd.addColorStop(0, config.mapColor||'#eee');
          grd.addColorStop(1, config.wallColor||'#ccc');
          ctx.fillStyle = grd;
        } else ctx.fillStyle = config.wallColor||'#aaa';
        ctx.fillRect(sx,sy,tileSize,tileSize);
      }));
 
Object.values(players).forEach(p=>{
    const isMain = p.id === player.id;
    const px = p.x;
    const py = p.y;

    const drawX = px*tileSize - camX;
    const drawY = py*tileSize - camY;
 
    ctx.fillStyle = '#0f0'; // main player green, others same color or choose another
    ctx.beginPath();
    ctx.arc(drawX, drawY, tileSize/2*0.6, 0, Math.PI*2);
    ctx.fill();

    ctx.fillStyle = '#000';
    ctx.font = config.usernameFont || '16px Verdana';
    ctx.textAlign = 'center';
    ctx.fillText(p.username, drawX, drawY - tileSize/2*0.7);
});

    }

    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);

})();

// server.js
const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
 
app.use(express.static(path.join(__dirname,'public')));

// === SERVER STATE ===
const players = {}; 
const bannedUsers = new Set(); 

// === HELPER FUNCTIONS ===
function broadcastActivePlayers(){
    const count = Object.keys(players).length;
    const msg = JSON.stringify({ type: 'activePlayers', count });
    wss.clients.forEach(client=>{
        if(client.readyState === WebSocket.OPEN) client.send(msg);
    });
}
  
function broadcastPlayers(){
    const payload = JSON.stringify({ type:'players', players });
    wss.clients.forEach(client=>{
        if(client.readyState === WebSocket.OPEN) client.send(payload);
    });
} 
function banPlayer(username){
    Object.entries(players).forEach(([id,p])=>{
        if(p.username === username){
            bannedUsers.add(username);
            p.ws.close(4001,'Banned');
            delete players[id];
            broadcastActivePlayers();
            broadcastPlayers();
        }
    });
}

// === WEBSOCKET CONNECTION ===
wss.on('connection', ws=>{
    console.log('WebSocket client connected');
 
    const id = Date.now() + Math.random().toString(16).slice(2);
    players[id] = { id, ws, username:null, x:0, y:0 };
 
    broadcastActivePlayers();

    ws.on('message', msg=>{
        try{
            const data = JSON.parse(msg);

            if(data.type==='join'){
                const username = data.username || 'Player';
                if(bannedUsers.has(username)){
                    ws.close(4001,'Banned');
                    delete players[id];
                    return;
                }
                players[id].username = username;
                 
                players[id].x = Math.random() * 10;
                players[id].y = Math.random() * 10;
                broadcastPlayers();
            }

            if(data.type==='move' && players[id]){
                const p = players[id];
                if(typeof data.x==='number') p.x = data.x;
                if(typeof data.y==='number') p.y = data.y;
                broadcastPlayers();
            }

            // cheat detected
            if(data.type==='cheatDetected' && players[id]?.username){
                banPlayer(players[id].username);
            }

        }catch(e){ console.error('Invalid message',e); }
    });

    ws.on('close', ()=>{
        console.log('WebSocket client disconnected');
        delete players[id];
        broadcastActivePlayers();
        broadcastPlayers();
    });

    ws.onerror = e => console.error('WebSocket error',e);
});
 
server.listen(80,()=>console.log('Server running at http://localhost'));

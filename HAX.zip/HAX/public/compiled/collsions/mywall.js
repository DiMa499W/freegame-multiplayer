// public/compiled/collisions/mywall.js
// Collision & movement logic for Hax game

(function(global){

  const Collisions = {};

  Collisions.isWalkable = function(map, x, y){
    const xi = Math.floor(x);
    const yi = Math.floor(y);
    if(!map[yi] || !map[yi][xi]) return false;
    return map[yi][xi] === 1; 
  };

  Collisions.movePlayer = function(player, input, map, speed){
    let nx = player.x;
    let ny = player.y;

    // Vertical movement
    if(input.up && Collisions.isWalkable(map, player.x, player.y - speed)) ny -= speed;
    if(input.down && Collisions.isWalkable(map, player.x, player.y + speed)) ny += speed;

    // Horizontal movement
    if(input.left && Collisions.isWalkable(map, player.x - speed, ny)) nx -= speed;
    if(input.right && Collisions.isWalkable(map, player.x + speed, ny)) nx += speed;

    player.x = nx;
    player.y = ny;
  };

  /*** Optimized collision check for nearby tiles ***/
  Collisions.checkNearby = function(map, player, radius){
    const x0 = Math.floor(player.x - radius);
    const y0 = Math.floor(player.y - radius);
    const x1 = Math.floor(player.x + radius);
    const y1 = Math.floor(player.y + radius);

    const blocked = [];
    for(let y=y0; y<=y1; y++){
      for(let x=x0; x<=x1; x++){
        if(map[y] && map[y][x] === 0) blocked.push({x,y});
      }
    }
    return blocked;
  };

  /*** Smooth movement with optional sliding ***/
  Collisions.smoothMove = function(player, targetX, targetY, factor=0.2){
    player.x += (targetX - player.x) * factor;
    player.y += (targetY - player.y) * factor;
  };

  global.Collisions = Collisions;

})(window);

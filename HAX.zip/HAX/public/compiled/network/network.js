// network.js
export default class Network {
  constructor(serverUrl = 'ws://localhost') {
    this.serverUrl = serverUrl;
    this.ws = null;
    this.callbacks = {};   
    this.connected = false;
    this.username = null;
  }

  connect(username = 'Player') {
    this.username = username;
    return new Promise((resolve, reject) => {
      this.ws = new WebSocket(this.serverUrl);

      this.ws.onopen = () => {
        console.log('Connected to server');
        this.connected = true;
        this.send('join', { username: this.username });
        resolve();
      };

      this.ws.onmessage = (msg) => {
        try {
          const data = JSON.parse(msg.data);
 
          if (data.type === 'banned') {
            alert('You have been banned from the server!');
            this.disconnect();
            return;
          }
 
          if (data.type && this.callbacks[data.type]) {
            this.callbacks[data.type](data);
          }
        } catch(e) {
          console.warn('Invalid WS message', e);
        }
      };

      this.ws.onclose = (e) => {
        console.log('Disconnected from server', e.code, e.reason);
        this.connected = false;
        if (this.callbacks['close']) this.callbacks['close'](); 
        if (e.code !== 4001) setTimeout(() => this.reconnect(), 3000);
      };

      this.ws.onerror = (err) => {
        console.error('WebSocket error', err);
        reject(err);
      };
    });
  }

  send(type, payload = {}) {
    if (this.ws && this.connected && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type, ...payload }));
    }
  }

  on(type, callback) {
    this.callbacks[type] = callback;
  }

  disconnect() {
    if (this.ws) this.ws.close(1000, 'Client disconnect');
    this.connected = false;
  }

  reconnect() {
    if (!this.connected) {
      console.log('Attempting reconnect...');
      this.connect(this.username);
    }
  }
}
